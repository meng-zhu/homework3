<?php
$result = '';
function glue ($val)
{
	global $result;
	$result .= $val;
}
$array = array ('a', 'b', 'c', 'd');//建立$array陣列
array_walk ($array, 'glue');//呼叫function傳入$array陣列
echo $result;
?>