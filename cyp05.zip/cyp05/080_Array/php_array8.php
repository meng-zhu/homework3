<?php
	$testArray = array("A1", "A2", "A18");
	sort($testArray);
	/*
	sort() 函数对索引数组进行升序排序。
	注释：本函数为数组中的单元赋予新的键名。原有的键名将被删除。
	如果成功则返回 TRUE，否则返回 FALSE。
	
	=> A1 A18 A2
	*/
	var_dump($testArray);
	
	echo "<br />";
	
	natsort($testArray);
	/*
	=> A1 A2 A18
	*/
	var_dump($testArray);
?>
