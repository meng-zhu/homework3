<?php

$a = array('xxx', 'book' => '書籍', 'yyy', 'desk' => '書桌', 'pen' => '筆');
//      key  0     book               1     desk              pen
foreach ($a as $k => $s)
{
	 echo "$k = $s<br>";
}
?>