<?php
$myArray['myName'] = 'Jeremy';
$myArray['myHeight'] = 191;
$myArray['myWeight'] = 91;
//          key        值
echo "Hello! My name is " . $myArray['myName']
?>