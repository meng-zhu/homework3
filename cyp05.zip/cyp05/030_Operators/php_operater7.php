<?php
  $x = 3;
  if ($x >= 10 && foo())
    echo "yes";
  else
    echo "no";
    
  echo "<hr>";

  $x = 3;
  if ($x >= 10 & foo())
    echo "yes";
  else
    echo "no";
    
function foo()
{
   echo "foo() is running.<br>";
}
/*
  $a = (false && foo());
  foo will never be called, since the result is known after evaluating false. On the other hand with
  當已經得知第一個條件式錯誤，foo將不會執行
  $a = (false & foo());
  foo will be called (also, the result is 0 rather than false).
  不論第一個條件是正確與否，foo執行了再說
*/
?>