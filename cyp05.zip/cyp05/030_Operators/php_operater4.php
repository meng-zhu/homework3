<?php
	$a = 10; $b = 1;
	$a += $b;//$a = $a + $b
	echo $a;
?>