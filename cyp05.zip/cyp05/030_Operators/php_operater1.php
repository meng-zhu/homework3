<?php
	$a = "I love ";
	$b = "you";
	echo $a . $b;
	/* 
	. 字串相接
	*/
?> 
