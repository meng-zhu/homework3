<?php
	$a = 100;
	$b = ($a > 0) ? "positive" : "negative";
	//                 正確          錯誤
	echo $b;
?>
