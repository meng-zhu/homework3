<?php

$x = 100;
$y = &$x;

$y = 200;
echo "x = $x </br>";

unset($x);
//echo "x = $x </br>";
echo "y = $y </br>";

/*
 $y = &$x;
 &$x > 似將$x指向$y的位置，$x的值會跟著$y變動
 unset($x); >刪除變數
*/

?>