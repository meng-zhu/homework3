<?php
  $x = 1;
  $y = $x++;
  echo "x = $x, y = $y";
  /*先將$x值給$y 再將$x+1*/  
  echo "<br>";



  $x = 1;
  $y = ++$x;
  echo "x = $x, y = $y";
   /*先將$x+1 再將$x值給$y*/  
  
?>
