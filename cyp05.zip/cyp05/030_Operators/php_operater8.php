<?php
  
    echo "flag 1<br>";
    @require("MyLibrary.php");
    echo "flag 2<br>";
 /*
 @ 不會出現錯誤訊息
 require 一旦出錯 則下面的程式碼都部會執行
 
 */
?>