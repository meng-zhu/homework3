<?php
	$a = 1;
	$b = $a + 2;//$b=1+2
	echo $b;
?>