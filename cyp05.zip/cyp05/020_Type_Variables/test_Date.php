<?php
  $x = getdate();
  echo gettype($x), "<br>";
  
  $x = date('Y-m-d H:i:s');
  echo $x, "<br>";
  echo gettype($x), "<br>";
  
  $x = gmdate('Y-m-d H:i:s');
  echo $x, "<br>";
  
  $x = strtotime(gmdate('Y-m-d H:i:s'));//也可寫成  $x = strtotime(now);
  echo $x, "<br>";
  echo gettype($x), "<br>";

  
  /*
    gettype($x) 得知他的型態種類
     若以 getdate() 取得時間，則型態種類為 array陣列
     若以 date('Y-m-d H:i:s')  gmdate('Y-m-d H:i:s')取得時間，則型態種類為字串
     strtotime 將時間描述解析為 UNIX 時間戳
  */
?>