<?php
$a = 20;
function myfunction($b) {
	//print "a=$a<br>";
	$a = 30;
	//print "a=$a<br>";
	global $a, $c; 
	//print "a=$a<br>";
	return $c = ($b + $a);
}
print myfunction(40) + $c;

/*
	global 全域變數
	
	php中函數與痊癒是完全隔絕的
	function用不到 $a = 20;

*/
?>