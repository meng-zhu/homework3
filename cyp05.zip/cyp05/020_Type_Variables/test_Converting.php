<?php

$a = 12;
$b = "34";

$result = $a + $b; // 46 
// $result = $a . $b; // 1234
// $result = $a + intval($b);  // 46
/* 
PHP會自動將字串轉變型態
*/
echo $result;

?>