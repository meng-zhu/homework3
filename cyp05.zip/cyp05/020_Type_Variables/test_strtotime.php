<?php
  $d = strtotime("2012-09-10");
  // $d = strtotime("2012-09-10 -3 days");
  // $d = strtotime("2012-09-10 +1 month");
  echo $d;
  echo "<br>";
  echo date("Y-m-d", $d);
  /*
  strtotime() 函数将任何英文文本的日期时间描述解析为 Unix 时间戳。
  語法  strtotime(now) or strtotime("時間")
  */
?>
