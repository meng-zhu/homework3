<?php
  $d = mktime(13, 30, 0, 9, 10, 2012);
  echo $d;
  echo "<br>";
  echo date("Y-m-d H:i:s", $d);
  
  /*
  mktime() 函数返回一个日期的 Unix 时间戳。
  語法  mktime(hour,minute,second,month,day,year,is_dst)
  */
?>
