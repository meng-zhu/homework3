<?php
  $x = 123;
  echo gettype($x), "<br>";
  
  $x = 123.0;
  echo gettype($x), "<br>";

  $x = "123.0";
  echo gettype($x), "<br>";
  
  $x = TRUE;
  echo gettype($x), "<br>";
  /* 
  gettype($x) 得知他的型態種類
  */
?>
