<?php
  define("test", 123);
  echo test, "<br>";
  /*
  define 宣告常數
  常數不同於變數之處：
  1.設定後不可變更
  2.不用以$開頭
  3.只能是字串或數字
  
  語法 define(name,value,case_insensitive)
  */
?>
