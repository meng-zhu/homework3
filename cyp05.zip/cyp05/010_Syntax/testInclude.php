<?php
  include("testDefine.php");
  // require("testDefine.php");

  echo test;
?>