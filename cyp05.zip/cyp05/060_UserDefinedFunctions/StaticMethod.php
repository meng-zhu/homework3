<?php

echo MathTool::calcTotal(1, 2, 3, 4, 5);

class MathTool {
	static function calcTotal () {
		$args = func_get_args();
		// var_dump($args);
		$total = 0;
		foreach ($args as $value) {//將$args 帶入 $value
			$total += $value;
		}
		return $total;
	}
}
/* 
func_get_args --- 傳回包含函式的參數列表的陣列
語法 : int func_get_args (void )
*/
?>
