<?php
function ShowStar($iCount, $sWhat = "*")//$iCount=2 , $sWhat = "*"
{
	$result = "";
	for ($i = 1; $i <= $iCount; $i++)
	{
		$result .= $sWhat;//$result=$result . $sWhat
	}
	echo $result;
}

$iHowMany = 2;
ShowStar($iHowMany);



?>