<?php
function ShowStar()
{
	echo "*****";
}

ShowStar(); 
//呼叫 function 

?>