<?php

$obj = new CTest();
$obj->firstName = "Jeremy";
$name = $obj->firstName;
echo "<hr>";
echo $name;


class CTest {

	private $_dataBag = array();
	
	public function __set($varName, $varValue)
	{
		echo "__set<br>";
		echo $varName, ": ", $varValue, "<br>";
		$this->_dataBag[$varName] = $varValue;
	}

	public function __get($varName)
	{
		echo "__get<br>";
		echo $varName, "<br>";
		return $this->_dataBag[$varName];
	}
		
}
/*
	__set() 方法用于设置私有属性值。
	__get() 方法用于获取私有属性值。
	__isset() 方法用于检测私有属性值是否被设定。
	__unset() 方法用于删除私有属性。

*/

?>
