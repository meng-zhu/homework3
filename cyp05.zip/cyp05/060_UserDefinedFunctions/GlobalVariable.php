<?php
$a = 20;
function myFunction($b) {
//	echo "a = $a<br>";
	$a = 30;
//	echo "a = $a<br>";
	global $a, $c;
//	echo "a = $a<br>";
//	echo "b = $b<br>";
	return $c = ($b + $a);
}
// 請預測答案是多少?120
/*
PHP 中 函數與痊癒是完全隔絕
*/
echo myFunction(40) + $c;
?>