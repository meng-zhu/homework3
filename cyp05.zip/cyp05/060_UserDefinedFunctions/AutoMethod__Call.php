<?php

$obj = new CTest();
$obj->Foo(1, 2, 3, 4);


class CTest {
	
	function __call($MethodName, $Parameters) {
		echo "Name: ", $MethodName, "<br>";
		echo "<pre>" . var_dump($Parameters) ."</pre>";
		echo "<hr>";
	}
	
}
/*
	__call() 这个方法用来监视一个对象中的其它方法。
	語法 __call(方法名, 參數)

*/

?>
