<?php
function ShowStar($iCount)//$iCount = 3
{
	$result = "";
	for ($i = 1; $i <= $iCount; $i++)
	{
		$result .= "*";
	}
	echo $result;
}

$iHowMany = 3;
ShowStar($iHowMany);

//1~3 ***

?>