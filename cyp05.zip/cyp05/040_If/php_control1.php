<?php
	$a = 100;
	if ($a > 0) {
		echo '$a is positive.';
	}
	/*如果$a>0 則執行以下程式*/
?>