<?php
	$a = -5;
	if ($a > 0) {
		echo '$a is positive.';
	} 
	else {
		echo '$a is negative';
	}
	/*如果$a>0 正確則執行以下程式，若不正確則執行else以下程式*/
?>