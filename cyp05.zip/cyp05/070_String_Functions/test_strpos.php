<?php

$s = "ABC1234ABC";
//    0123456789
$iPos = strpos($s, "1234");  // 3

if ($iPos !== false) {
    echo "found";
}
else {
    echo "not found";
}
/*
strpos() 函数查找字符串在另一字符串中第一次出现的位置。
注释：strpos() 函数对大小写敏感。
注释：该函数是二进制安全的。
*/

?>
