<?php
$sData = "";
$f = fopen("pick3.txt", "r");//開檔案
while (!feof($f))//判斷是否為該檔案最末端
{
	$line = fgets($f);//取資料
	$sData .= Trim($line); //trim() 函数移除字符串两侧的空白字符或其他预定义字符。
}
fclose($f);//關檔案
//echo $sData;  $sData =908872526535442041985072568716

//GetHotCodeList
$result = "01234567890";
$iLen = strlen($sData);//30
for ($iPos = 0; $iPos < $iLen; $iPos++)//0~29
{
	$ch = substr($sData, $iPos, 1);
	$result = $ch . str_replace($ch, "", $result);
//	echo $result . "<br>";
	// exit();

}
echo substr($result, 0, 5) . "-" . substr($result, 5, 5);
?>