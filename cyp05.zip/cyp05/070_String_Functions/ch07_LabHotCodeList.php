<?php
$sData = "908872526535442041985072568716";
$result = "01234567890";
$iLen = strlen($sData);//30
for ($iPos = 0; $iPos < $iLen; $iPos++)//ipos = 0 ; ipos < 30;ipos++
{
	$ch = substr($sData, $iPos, 1);//擷取字串內容
//	echo $ch . "<br>";
	$result = $ch . str_replace($ch, "", $result);
}
//	echo $result;	
echo substr($result, 0, 5) . "-" . substr($result, 5, 5);
//61785-20943

/*
strlen(string) 取得字串長度

str_replace($ch, "", $result); 替換字串

PHP substr() 函數的用途是用來取得部分字串內容，可以設定要開始擷取的字元位置與總共要擷取的字元數量。

基本的語法

substr( $string , $start , $length )

*/
?>