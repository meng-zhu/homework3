<?php
$f = fopen("pick3.txt", "r");//開啟pick3.txt 以讀方式
while (!feof($f)) //feof() 函数检测是否已到达文件末尾。
{
	$line = fgets($f);//取得資料
	echo "$line<br>";
}
fclose($f);//關閉
echo "--End--";
?>